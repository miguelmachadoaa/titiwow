$("table").DataTable({
    responsive:true
});

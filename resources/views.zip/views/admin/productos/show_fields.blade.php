<!-- Id Field -->
<div class="form-group">
    {!! Form::label('id', 'Id:') !!}
    <p>{!! $alpProductos->id !!}</p>
    <hr>
</div>

<!-- Undefined Field -->
<div class="form-group">
    {!! Form::label('undefined', 'Undefined:') !!}
    <p>{!! $alpProductos->undefined !!}</p>
    <hr>
</div>

<!-- Name Producto Field -->
<div class="form-group">
    {!! Form::label('name_producto', 'Name Producto:') !!}
    <p>{!! $alpProductos->name_producto !!}</p>
    <hr>
</div>


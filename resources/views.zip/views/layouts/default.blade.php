    @include('layouts.header')
    
    <!-- slider / breadcrumbs section -->
    @yield('top')

    <!-- Content -->
    @yield('content')

   @include('layouts.footer')

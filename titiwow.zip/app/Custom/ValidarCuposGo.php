<?php 
namespace App\Custom;

class ValidarCuposGo
{
    public $DocumentoEmpleado;

    public function __construct($DocumentoEmpleado)
    {
        //
        $this->DocumentoEmpleado=$DocumentoEmpleado; 
    }

}